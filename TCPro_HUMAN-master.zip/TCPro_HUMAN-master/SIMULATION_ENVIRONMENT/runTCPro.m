%RUNTCPRO() This script runs TCPro on a list of drugs in folders.dat using
%the provided list of donors and drug information.
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

%Add all TCPro paths into Matlab path
original_dir=pwd;
cd ..
parent_dir=pwd;
addpath(genpath(parent_dir));
cd(original_dir);

% Read folder names
folders = readtable('folders.dat','Delimiter','\t');

for i = 1:height(folders)
        
    drug = folders.folders{i}; %folder name
    cd(drug) %change diractory
    cd Bin %we'll run TCPro in the bin directory
    runalldonor(drug) %Run TCPro on all donors
    cd ..
    cd ..
    
end