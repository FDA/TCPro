%CLEANOUTPUTFOLDERS() This script cleans all output folders to prepare for
%new simulations
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

% Read fodler names
folders = readtable('folders.dat','Delimiter','\t');

% Delete contents of each output folder 
for i = 1:height(folders)
    drug = folders.folders{i};
    cd(drug)
    cd Output
    unix('rm *')
    cd ..
    cd ..
end