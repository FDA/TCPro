function  [antigenname,cohortname,Nrun,MeanFp,StdFp,SampleConcentration,cohort,SIcutoff,sigcutoff,FLAGpopulationdrugfreqavail] = readinputs()
%READINPUTS() Reads the input files present in the drug Input folders and
%stores data under different variables, writes cohort information file
%and results of NetMHCIIPanv3.2 predictions.
%   OUTPUTS:
%   1. antigenname: Name of the drug
%   2. cohortname: Name of the cohort of interest
%   3. Nrun: Number of TCPro simulations
%   4. MeanFp: Population Mean Frequency of drug specific precursor CD4+s (per million)
%   5. StdFp: Standard deviation of population Fp
%   6. SampleConcentration: the sample concentration according to the experimental protocol
%   7. cohort: cohort data file that includes HLA types, binding affinities
%   8. SIcutoff: Stimulation index cutoff for the assays typically 1.9 or 2
%   9. sigcutoff: desired p-value for significance in SI, typically 0.05
%   10. FLAGpopulationdrugfreqavail: 1 if drug specific precursor T cell
%   frequencies could be obtained from literature and saved as a file
%   present in the path.
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

%Read the input file
fileID = fopen('options.dat');
options = textscan(fileID,'%s %*[^\n]');
fclose(fileID);

antigenname = options{1,1}{1,1}; %Name of the drug
cohortname = options{1,1}{2,1}; %Name of the cohort
cohorthlafilename = options{1,1}{3,1}; %Cohort file with HLA-DRB1s
fastaseq = options{1,1}{4,1}; %Drug a.a. sequence in fasta format
Nrun = str2num(options{1,1}{5,1}); %Number of TCPro sims
FLAGpopulationdrugfreqavail = str2num(options{1,1}{6,1}); %0 if MeanFp and StdFp will be used, 1 if values from '12248_2019_368_MOESM4_ESM.xlsx' will be used
MeanFp = str2num(options{1,1}{7,1})/1e6; %Population Mean Frequency of drug specific precursor CD4+s (per million)
StdFp = str2num(options{1,1}{8,1})/1e6; %standard deviation of population Fp
SIcutoff = str2num(options{1,1}{9,1}); %Stimulation index cutoff typically 1.9 or 2
sigcutoff = str2num(options{1,1}{10,1}); %p-value for significance in SI
NetMHCIIPanlocation = options{1,1}{11,1}; %Location of NetMHCIIPan e.g. NetMHCIIPanlocation = '/home/osman.yogurtcu/Documents/NetMHCIIPanVersions/netMHCIIpan-3.2/';
locBLASTbin = options{1,1}{12,1}; %local folder path Blast
locEpitopeDB = options{1,1}{13,1}; %local folder path for epitopes (15-mer) database
EpitopeDB  = options{1,1}{14,1}; %Name of EpitopeDB for BLAST

% Find the sample concentration according to the experimental protocol
% Find the foreignness score of a drug (.csv)
% Find all the peptides (.csv)
SampleConcentration = read15mers(fastaseq,locBLASTbin,locEpitopeDB,EpitopeDB,NetMHCIIPanlocation);

%Read data from 15mers_KDs_Pepitopes created by read15mers()
Allabout15mers = readtable('15mers_KDs_Pepitopes.csv');
KDVals = Allabout15mers{:,2:end-1};
Pepitope = Allabout15mers{:,end};
data = 1./sum(1./KDVals,1); %Effective KD's per allele

%% Read cohort HLAs and assign DRB1 affinities and drug foreignness to each cohort member - fill in the cohort dataset
cohort = readtable(cohorthlafilename,'Delimiter',',');

%Find unique alleles
uniqHLA = unique([cohort{:,2};cohort{:,3}]);

%Assign allele indexes to the table and write effective binding KD affinity
t = readtable('allWorldAlleles.dat','Delimiter',',');
t.Donors=categorical(t.Donors);
for i = 1:length(uniqHLA)    
    
    cohort(strcmp(cohort{:,2},uniqHLA{i}),4) = {i}; %Assign Allele index
    cohort(strcmp(cohort{:,3},uniqHLA{i}),5) = {i}; %Assign Allele index
    KD = [];
    
    thehla = uniqHLA{i};
    thehla = ['DRB1_' thehla([end-4 end-3 end-1 end])];

    indexwithinAllWorldAlleles = find(t.Donors==thehla);
    KDeff = data(1,indexwithinAllWorldAlleles);
    
    cohort(strcmp(cohort{:,2},uniqHLA{i}),6) = {KDeff}; %Effective KD values
    cohort(strcmp(cohort{:,3},uniqHLA{i}),7) = {KDeff}; %Effective KD values
    
end
cohort(find(cohort{:,6}==cohort{:,7}),8)={1}; %If donor homozygous = 1, else 0

% For each donor in the cohort, obtain the MHCII alleles and write binding affinity data into cohort dataset
for donindex = 1:height(cohort)
  
    hla1 = strrep(strrep(cohort{donindex,2}{:}(5:end),'*','_'),':','');
    hla2 = strrep(strrep(cohort{donindex,3}{:}(5:end),'*','_'),':','');

    a1 = find(strcmp(hla1,string(t{:,1})));
    a2 = find(strcmp(hla2,string(t{:,1})));
    cohort(donindex,9) = {dot(sum(1./KDVals(:,[a1 a2]),2),Pepitope)}; %PhiNumerator
    cohort(donindex,10) = {cohort{donindex,9}/sum([1/cohort{donindex,6} 1/cohort{donindex,7}])}; %Phi
    
end

% Assign Column names for the cohort dataset
cohort.Properties.VariableNames(4) = {'Allele1index'};
cohort.Properties.VariableNames(5) = {'Allele2index'};
cohort.Properties.VariableNames(6) = {'KDeff1'};
cohort.Properties.VariableNames(7) = {'KDeff2'};
cohort.Properties.VariableNames(8) = {'Homozygous'};
cohort.Properties.VariableNames(9) = {'PhiNumerator'};
cohort.Properties.VariableNames(10) = {'Phi'};

%Delete/move files
movefile('15mers.csv','../Output/');
movefile('15mers_KDs_Pepitopes.csv','../Output/');
movefile('15mers_Ranks.csv','../Output/');
movefile('NetMHCIIpan_out.csv','../Output/');
delete('input.fa');
delete('results.txt');
delete('out.dat');
delete('NetMHCIIpan_out.xls')

% Write cohort member Effective KDs into the output folder
cd ../Output
writetable(cohort,[antigenname '_' cohortname '_cohortKDeff.csv'],'Delimiter',',');
cd ../Input