function dydt=f(t,y,pars) %#ok<INUSL>
%F() Calculates and presents all differential equations that are used to
%simulate cell proliferation/differentiation in the assay wells. This code
%is based on the work of Chen et al.: Chen, X., T. P. Hickling, and 
%P. Vicini. "A mechanistic, multiscale mathematical model of immunogenicity 
%for therapeutic proteins: part 1—theoretical model." CPT: pharmacometrics 
%& systems pharmacology 3.9 (2014): 1-9. 
%   INPUTS: 
%   1. t: time point
%   2. y: array for state variables
%   3. pars: array for model parameters
%   OUTPUT:
%   1. dydt: Array containing numeric values for differential equations at
%   time point t.
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

%% Parameter vector data is extracted 
NA=pars(1); %Avogadro constant
Dose=pars(2); %#ok<NASGU> intitial therapeutic protein in the plasma compartment, pmol
Vp=pars(3); %Well volume, L
%% T-epitope characteristics of therapeutic proteins
N=pars(4); %Number of epitopes
kon=reshape(pars(5:(4+6*N)),N,6); %Peptide-MHCII binding forward rate, pM-1day-1
koff= reshape(pars((5+6*N):(4+12*N)),N,6); %Peptide-MHCII binding off-rate, day-1
%% Dendritic cells related parameters
BetaID=pars(5+12*N); %death rate of immature dendritic cells, day-1
DeltaID=pars(6+12*N); %maximum activation rate of immature dendritic cells, day-1
KMS=pars(7+12*N); % LPS concentration at which immature DC activation rate is 50% maximum, day-1
BetaMD=pars(8+12*N); %death rate of mature dendritic cells, day-1
%% Antigen presentation related parameters
AlphaAgE=pars(9+12*N); %Ag internalization rate constant by mature dendritic cells, day-1
BetaAgE=pars(10+12*N); %degradation rate for AgE in acidic vesicles, day-1
Beta_p=pars(11+12*N); %degradation rate for T-epitope peptide, day-1
BetaM=pars(12+12*N); %degradation rate for MHC-II, day-1
Beta_pM=pars(13+12*N); %degradation rate for pME, day-1
kext=pars(14+12*N); %exocytosis rate for peptide-MHC-II complex from endosome to cell membrane, day-1
kin=pars(15+12*N); %internalization rate for peptide-MHC-II complex on DC membrane, day-1
KpM_N=pars(16+12*N); %number of peptide-MHCII to achieve 50% activation rate of na�ve helper T cells
VD=pars(17+12*N); %volume of a dendritic cell, L
VE=pars(18+12*N); %volume of endosomes in a dendritic cell, L
%% T helper cells related parameters
RhoNT=pars(19+12*N); %maximum proliferation rate for activated helper T cells, day-1
BetaNT=pars(20+12*N); %death rate of naive helper T cells, day-1
DeltaNT=pars(21+12*N); %maximum activation rate of naive helper T cells, day-1
RhoAT=pars(22+12*N); %maximum proliferation rate for activated helper T cells, day-1
BetaAT=pars(23+12*N); %death rate of activated helper T cells, day-1
Fp=pars(24+12*N); %Precursor helper T cell frequency
%% Initial conditions as parameters in the differential equations:
ID0=pars(25+12*N); %#ok<NASGU> Initial concentration for immature dendritic cells
ME0=pars((26+12*N):(31+12*N)); %Initial MHCII concentration, pmole
EpitopeRatio=pars(32+12*N); %Epitope propensity score of the drug for the specific cohort member

%% State variables for the differential equations
% Ag, antigenic protein in the plasma compartment
Ag=y(1);
% MS, maturation signal for Immature dendritic cells
MS=y(2);
% ID, Immature dendritic cells
ID=y(3);
% MD, mature dendritic cells
MD=y(4);
%AgE, Ag in the endosomes
AgE=y(5);
% pE, free epitope peptides from Ag digestion (N Epitopes)
pE=y((5+1):(5+N));
% ME(1:6), free MHC II molecule in endosome (6 MHCIIs allowed)
ME=y((6+N):(11+N));
% pME(N,6),	epitope peptide-MHC II complex in endosomes
pME=reshape(y((12+N):(11+7*N)),N,6); % pME is in a matrix form, N epitopes against 6 possible MHC alleles
% pM(N,6), epitope peptide-MHC II complexes on dendritic cell membrane
pM=reshape(y((12+7*N):(11+13*N)),N,6);
% M, free MHC II molecule on dendritic cell membrane (6 MHCIIs allowed)
M=y((12+13*N):(17+13*N));
% NT, naive helper T cells
NT=y(18+13*N);
% AT_N activated helper T cells (N Epitopes)
AT_N=y((19+13*N));
% Prolif, Placeholder for proliferating cells MD+AT
Prolif=y((20+13*N):(23+13*N)); %#ok<NASGU>

%% Calculate functions for helper T cells activation, proliferation, or differentiation

% Adding up all the pM molecules from one epitope against 6 different MHC alleles
pM_NUMBER=EpitopeRatio*sum(pM*ones(6,1)*1E-12*NA); %pM is an Nx6 matrix times 6x1 gives Nx1 summing it gives 1x1 scalar number

% The activation function D for helper T cells
D_N=(MD/(MD+sum(Fp.*NT)+sum(AT_N)))*(((pM_NUMBER)./(pM_NUMBER+KpM_N)));

% The proliferation/differentiation function E for helper T cells
E_N=(MD/(MD+sum(Fp.*NT)+sum(AT_N)))*((pM_NUMBER-KpM_N)./(pM_NUMBER+KpM_N));

%% The Differential Equations
% Ag, y(1), total amount of antigenic protein in the well, pmole
dydt(1,1)=-(ID+MD)*AlphaAgE*VD*(Ag/Vp);

% MS, y(2), maturation signal, particularly, LPS, for immature dendritic cells, ng
dydt(2,1)=-(ID+MD)*AlphaAgE*VD*(MS/Vp);

% ID, y(3), immature dendritic cells, cells
dydt(3,1)=-BetaID*ID-DeltaID*ID*(MS/Vp)/((MS/Vp)+KMS);

% MD,	y(4), mature dendritic cells, cells
dydt(4,1)=DeltaID*ID*(MS/Vp)/((MS/Vp)+KMS)-BetaMD*MD;

%AgE, y(5), Ag in the endosome, pmole
dydt(5,1)=AlphaAgE*VD*(Ag/Vp)-BetaAgE*AgE;

% pE, y((5+1):(5+N)), T-epitope peptides from Ag digestion, pmole
dydt((5+1):(5+N),1)=BetaAgE*AgE-Beta_p*pE-kon.*(pE*(ME'/VE))*ones(6,1)+koff.*pME*ones(6,1);

% ME, y((6+N):(11+N)),free MHC-II molecule in endosome, pmole
dydt((6+N):(11+N),1)= BetaM*(ME0-ME)-(ones(1,N)*(kon.*(pE*(ME'/VE))))'+(ones(1,N)*(koff.*pME))'+kin*M;

% pME, y((12+N):(11+7*N)), T-epitope-MHC-II complex in endosome, pmole
dydt((12+N):(11+7*N),1)= reshape(kon.*(pE*(ME'/VE))-koff.*pME -Beta_pM*pME -kext*pME,6*N,1);

% pM,	y((12+7*N):(11+13*N)), T-epitope-MHC-II complex on dendritic cell membrane, pmole
dydt((12+7*N):(11+13*N),1)=reshape(kext*pME -koff.*pM,6*N,1);

% M, y((29+13*N):(34+13*N)), free MHC-II molecule on dendritic cell membrane, pmole
dydt((12+13*N):(17+13*N),1)=-kin*M +(ones(1,N)*(koff.*pM))';

% NT, y(18+13*N), naive helper T cells pool, cells
dydt(18+13*N,1)=MD*RhoNT-BetaNT*NT-sum(DeltaNT*D_N.*Fp.*NT);

% AT_N, y((19+13*N):(18+14*N)), activated helper T cells derived from NT cells
dydt((19+13*N),1)=DeltaNT*D_N.*Fp.*NT+RhoAT.*E_N.*AT_N-BetaAT*AT_N; 

% Prolif, placeholder for proliferating cells MD+AT, y((19+14*N):(18+15*N)) 
sAt = E_N>=0; %Making sure E_N is positive so we take into account only the proliferating cells
dydt((20+13*N):(23+13*N),1)=[MD*RhoNT; sAt.*RhoAT.*E_N.*AT_N; DeltaNT*D_N.*Fp.*NT; abs(RhoAT.*E_N.*AT_N)];