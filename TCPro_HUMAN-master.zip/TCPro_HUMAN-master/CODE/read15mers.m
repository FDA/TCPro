function Concentration = read15mers(fastaseq,locBLASTbin,locEpitopeDB,EpitopeDB,NetMHCIIPanlocation)
%READ15MERS() Reads the aminoacid sequence of the protein drug, then for
%each possible 15-mer that can be cleaved out of the protein runs a BLAST
%against the MHCII antigen dataset obtained from the IEDB to assign epitope
%likelihood to every 15-mer. In addition, for every 15-mer, it runs an
%MHCIIPan to obtain the binding affinity/percentile rank and stores all the
%information in the .csv output files which will be read by readinputs()
%   INPUTS:
%   1. fastaseq: Drug a.a. sequence in fasta format  
%   2. locBLASTbin: local folder path Blast 
%   3. locEpitopeDB: local folder path for epitopes (15-mer) database
%   4. EpitopeDB: Name of EpitopeDB for BLAST
%   5. NetMHCIIPanlocation: Location of NetMHCIIPan
%   OUTPUT:
%   1. Concentration: the sample concentration according to the experimental protocol
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

% Initialization step
ProteinSeqLenCutoff = 39;
ind = 0;
totalPlength = 0; %total aminoacid count of the drug
myseq = fastaread(fastaseq); %Read fasta sequence
numchain = length(myseq); %Number of chains in a protein drug
x = 15; %desired peptide sequence length fixed, 15mers only
MaximumNumberofxmers = 0; %Max. num possible x-mers cleaved-out

%Read through the number of chains of the protein in the protein fasta file, 
%then calculate the total number of 15-mers that can be cleaved out of this 
%sequence and also calculate the total number of amino acids - Plength
for ns = 1:numchain
    
    chain = myseq(ns).Sequence; % amino acid sequence of the chain
    
    %store sequence information in chains cell structure
    chains{ns,1} = chain; 
    chainID(ns) = ns; %chain index number
    
    %Check if the new chain has the same exact sequence as one of the other
    %chains (e.g. is it a homodimer?) - then those would have the same chainID
    for k = 1:ns-1
        if strcmp(chains{ns,1},chains{k,1})
            chainID(ns) = chainID(k);
            break;
        end
    end
    
    L = length(chain); %Chain sequence length
    totalPlength = totalPlength + L; %cumulative sequence length
    MaximumNumberofxmers = MaximumNumberofxmers + floor(L/x); %what is the maximum number of 15-mers that can be cleaved out of this chain
    for i = 8:length(chain)-7 %Obtain the aminoacid sequences of all possible 15mers
        ind = ind+1;
        seqs{ind,1} = chain(i-7:i+7);
        seqs{ind,2} = ns;
        seqs{ind,3} = chainID(ns);
    end
    
end

%% Classify drug: Protein or peptide?
if totalPlength >=ProteinSeqLenCutoff %So that Exenatide and all large proteins qualify as a protein-drug
    %classify as protein
    T = table((1:ind)',[seqs{:,2}]',[seqs{:,3}]',[seqs(:,1)]);
else
    %classify as peptide    
    T = table(1,1,1,{chain});    
end
%Write out all the 15mers into 15mers.csv
T.Properties.VariableNames = {'Index','ChainNum','ChainID','xmers'};
writetable(T,'15mers.csv','Delimiter',',');

% Assign concentrations to the drugs (Proteins~0.3uM | peptides 5uM)
if totalPlength >=ProteinSeqLenCutoff
    %classify as protein
    PofCleavability = MaximumNumberofxmers/ind;
    Concentration = PofCleavability*0.3; %MicroMolar
else
    %classify as peptide
    Concentration = 5.0; %MicroMolar
end

%% Run NetMHCIIPan
%Read unique alleles found in the world
HLAs = readtable('allWorldAlleles.dat','Delimiter',',');
HLAs = sortrows(HLAs);
HLAlist = '';
for i = 1:height(HLAs)
    HLAlist = [HLAlist ',' HLAs{i,1}{:}];
end
HLAlist = HLAlist(2:end);

%Run NetMHCIIPan on the 15mers from the proteins or peptides
if totalPlength >=ProteinSeqLenCutoff
    % classify as protein
    command = [NetMHCIIPanlocation 'netMHCIIpan -inptype 0 -f sequence.fasta -a ' HLAlist ' -xls NetMHCIIpan_out.xls > out.dat'];
else
    % classify as peptide
    unix('awk ''{if (NR!=1) {print}}'' sequence.fasta > peptide.fasta');
    command = [NetMHCIIPanlocation 'netMHCIIpan -inptype 1 -f peptide.fasta -a ' HLAlist ' -xls NetMHCIIpan_out.xls > out.dat'];
end

% Check if an output file was already generated for this drug
if exist('../Output/NetMHCIIpan_out.csv') == 2 && totalPlength >=ProteinSeqLenCutoff  %TEMPORARY  
    status = unix('cp ../Output/NetMHCIIpan_out.csv .');    
else
    status = unix(command);
    status = unix('cp NetMHCIIpan_out.xls NetMHCIIpan_out.csv');
end

%Read the results of NetMHCIIPan (Kd and Rank values)
tbl = readtable('NetMHCIIpan_out.csv');
tbl(:,end-1:end) = [];

%Write binding affinity KD into Kds table
Kds = tbl(:,[2 5:3:end]);
Kds.Properties.VariableNames(2:end) = HLAs{:,1};

%Write binding percentile rank into Ranks table
Ranks = tbl(:,[2 6:3:end]);
Ranks.Properties.VariableNames(2:end) = HLAs{:,1};

%% Obtain Probability of CD4+ Epitope Likelihood using function isAntigenHuman
if totalPlength >=ProteinSeqLenCutoff
    % classify as protein
    for i = 1:height(Kds)
        [foreign(i,1),~,~,~] = isAntigenHuman(Kds{i,1}{:},locBLASTbin,locEpitopeDB,EpitopeDB);
    end
else
    % classify all studied peptides as foreign
    foreign = 1.0;
end

%Write all binding affinity and rank info into two separate .csv files
Kds{:,width(Kds)+1} = foreign;
Kds.Properties.VariableNames(end) = {'P_epitope'};
writetable(Kds,'15mers_KDs_Pepitopes.csv','Delimiter',',');
writetable(Ranks,'15mers_Ranks.csv','Delimiter',',');


function [ProbForeign,Data,alignmentredundancymat,lenuniqscores] = isAntigenHuman(seq,locBLASTbin,locEpitopeDB,EpitopeDB)
%This function reads the epitopes obtained from IEDB and derives
%foreignness score for each drug sequence 'seq' - 15mer peptide of a drug

myseq(1).Sequence = seq; %eg 'SKPQGRIVGGKDCPKGECPWQVL'
myseq(1).Header = '15mer';
if exist('input.fa')==2
    delete('input.fa');
end
fastawrite('input.fa',myseq);

% Parameters for foreignness probability distribution
k = 1;
a = 7.5;
ProbForeign = 0;
alignmentredundancymat = [];
lenuniqscores = nan;

% Run ungapped BLAST on the 15mer sequence
command = [locBLASTbin 'blastp -ungapped -db ' locEpitopeDB EpitopeDB ' -query input.fa -out results.txt -sum_stats T -evalue 200000 -matrix PAM30 -comp_based_stats 0'];
status = unix(command);

%Read BLAST results
Data = blastreadlocal('results.txt',0);

%Check how many antigen-like epitopes were found that resembles our 15-mer
numhits = length(Data.Hits);

if numhits>0
    
    %For each epitope check the number of positives and identities
    %Obtain foreignness scores
    for i = 1:numhits
        
        positives = Data.Hits(i).HSPs(1).Positives.Match;
        identities = Data.Hits(i).HSPs(1).Identities.Match;
        scores(i) = identities + 0.5*(positives-identities);
        
    end
    
    %Check if any of the hits are redundant in the results.txt output file
    alignmentredundancymat = zeros(numhits);
    for i = 1:numhits-1
        for j = i+1:numhits
            subseqavail = length(strfind(Data.Hits(i).HSPs(1).Alignment(3,:),Data.Hits(j).HSPs(1).Alignment(3,:)));
            alignmentredundancymat(i,j) = sign(subseqavail);
        end
    end
    
    %Eliminate redundancy, if it exists
    scores(find(sum(alignmentredundancymat)>0))=[]; 
    lenuniqscores = length(scores);
    
    %Calculate Foreignness score
    ex = sum(exp(-k*(a-scores)));
    ProbForeign = ex/(1+ex);
    
end