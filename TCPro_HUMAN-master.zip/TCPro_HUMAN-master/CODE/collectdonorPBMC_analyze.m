function [DC,NK,BC,CD4,CD8,MC] = collectdonorPBMC_analyze(MinNumPBMCs,MaxNumPBMCs,Vp,seed)
%COLLECTDONORPBMC_ANALYZE() Calculates and presents the initial number of
%cells in assay wells randomly selected from within total cell frequencies
%observed in PBMCs.
%   INPUTS: 
%   1. MinNumPBMCs: Minimum PBMC concentration (number of cells/mililiter)
%   2. MaxNumPBMCs: Minimum PBMC concentration (number of cells/mililiter)
%   3. Vp: Volume of the assay well (microliters)
%   4. seed: random seed to select different cell frequencies for each run
%   OUTPUTS:
%   1. DC: Dendritic cell count in the well
%   2. NK: Natural Killer cell count in the well
%   3. BC: B Cell count in the well
%   4. CD4: Helper T cell count in the well
%   5. CD8: CTL count in the well
%   6. MC: Monocyte count in the well
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

Vp = Vp*1e3; %conversion to mililiters

% Calculate randomly selected frequency of cells
NumCellsper_ml(:,1) = distributionofCells(MinNumPBMCs,MaxNumPBMCs,seed);

% Multiply to find the individual cell counts
DC = Vp*NumCellsper_ml(1);
NK = Vp*NumCellsper_ml(2);
BC = Vp*NumCellsper_ml(3);
CD4 = Vp*NumCellsper_ml(4);
CD8 = Vp*NumCellsper_ml(5);
MC = Vp*NumCellsper_ml(6);

% Write out selected cell numbers if desired, into a file called InitNumCell.txt 
% if ~exist('InitNumCell.txt')
%     PBMCcells{1}='DC: ';
%     PBMCcells{2}='NK: ';
%     PBMCcells{3}='BC: ';
%     PBMCcells{4}='CD4: ';
%     PBMCcells{5}='CD8: ';
%     PBMCcells{6}='MC: ';
%     fileID = fopen('InitNumCell.txt','w');
%     fprintf(fileID,'%s\n','Init Cell Counts');
%     for i = 1:6
%         fprintf(fileID,'%s %d\n', PBMCcells{i}, Vp*NumCellsper_ml(i));
%     end
%     fclose(fileID);
% end

% Print out selected cell numbers if desired on the command line
% disp('Init Cell Counts');
% disp(['DC: ' num2str(round(DC))]);
% disp(['NK: ' num2str(round(NK))]);
% disp(['BC: ' num2str(round(BC))]);
% disp(['CD4: ' num2str(round(CD4))]);
% disp(['CD8: ' num2str(round(CD8))]);
% disp(['MC: ' num2str(round(MC))]);