function runalldonor(drug)
%RUNALLDONOR() TCPro simulation for "drug".
%   INPUT: 
%   1. drug: Name of the drug to be simulated. Drug data is contained in
%   /SIMULATION_ENVIRONMENT/drug
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

%% Preliminaries
% If the drug specific precursor frequencies (Fp) for a drug was obtained 
% from the literature use this file which is located under
% TCPRO_LIBRARY
drugfreqfromliteraturefilename = '12248_2019_368_MOESM4_ESM.xlsx';

rng(0) %OPTIONAL: initialize the random number generator to make the results in this simulation repeatable.
cd ../Input %Go to the inputs folder of the drug in question, and read the inputs
[antigenname,cohortname,Nrun,MeanFp,StdFp,SampleConcentration,cohort,SIcutoff,sigcutoff,FLAGpopulationdrugfreqavail] = readinputs();
cd ../Bin %Go back to Bin/
disp(drug)

%Probability distribution for initial Maturation signal concentration in the well
%Obtained by fitting - Yogurtcu et al. 2019 AAPS - See supplementary 12248_2019_368_MOESM1_ESM for description
pdMS0 = makedist('Exponential','mu',5.2285);

%% Matrix-Vector Initialization
randomseeds = randi(2^32-1,Nrun,height(cohort)); %Generating a random seed matrix of size NSimulationRuns x NumberofDonorsinCohort
IncoBinary = zeros(Nrun,height(cohort)); %Thymidine incorporation binary results container
ELISBinary = IncoBinary; %ELISpot binary results container
similarity = zeros(Nrun,1); %Container to show the percent similarity between Inco (thymidine incorporation assay) and ELIspot binary results

%% Run simulation
for traj = 1:Nrun %Number of simulation runs
    
    for i = 1:height(cohort) %Cohort size
        
        theseed = randomseeds(traj,i); %get the seed for randomization 
        rng(theseed); %Making sure that Fps, MS0, cell type distributions are consistently random per cohort member

        if FLAGpopulationdrugfreqavail==1  % if drug frequencies could be obtained from the literature: 12248_2019_368_MOESM4_ESM.xlsx
            Fptable = readtable(drugfreqfromliteraturefilename,'Sheet',drug);
            randomFp = 1e-6*Fptable{randi([1 height(Fptable)],1,1),1};
        else
            % if no available Fp literature value was found, then use the Fp value
            % written in the input files - assume normal distribution
            randomFp = random('Normal',MeanFp,StdFp);
        end  
        
        if randomFp>0 %In case the selected precursor frequency for a donor is a positive value
            [Response{traj,i},pval{traj,i}] = Main_human(theseed,cohort(i,:),SampleConcentration,randomFp,pdMS0);
            temp = Response{traj,i};
            temp2 = pval{traj,i};
            IncoBinary(traj,i) = sign(sum(((temp(1:4))>SIcutoff).*(temp2(1:4)<sigcutoff)));
            ELISBinary(traj,i) = (temp(5)>SIcutoff).*(temp2(5)<sigcutoff);
        else %Don't do TCPro simulations, if Fp=0, assign FALSE (no drug response) for this donor for this simulation
            IncoBinary(traj,i) = 0;
            ELISBinary(traj,i) = 0;
        end
        
    end
    % Percent Similarity ELISpot vs Thymidine Incorporation
    similarity(traj,1) = 100*sum(~xor(IncoBinary(traj,:)',ELISBinary(traj,:)'))/height(cohort);
    
end

% Combined ELISpot and Thymidine Incorportaion assays
COMBOBinary = IncoBinary.*ELISBinary;

%% Calculate statistics
% Percent Responders
Inco = sum(IncoBinary,2);
ELIS = sum(ELISBinary,2);
COMBO = sum(COMBOBinary,2);

% Mean and 95% CI in percent responders
pd = fitdist(Inco,'Binomial','NTrials',size(IncoBinary,2));
IncoAllStats = 100*icdf(pd,[0.025 0.5 0.975])/size(IncoBinary,2);
pd = fitdist(ELIS,'Binomial','NTrials',size(IncoBinary,2));
ELISAllStats = 100*icdf(pd,[0.025 0.5 0.975])/size(IncoBinary,2);
pd = fitdist(COMBO,'Binomial','NTrials',size(IncoBinary,2));
COMBOAllStats = 100*icdf(pd,[0.025 0.5 0.975])/size(IncoBinary,2);

% ELISpot vs Thymidine incorporation %similarity and 95% CI
pd = fitdist(similarity,'Normal');
SimilarityStats = icdf(truncate(pd,0,100),[0.025 0.5 0.975]);

%% Write output
cd ../Output
%Write summary output
fileID = fopen([antigenname '_' cohortname '_Summary.dat'],'w');
header = ['%Responders to ' antigenname ' in the cohort (' cohortname '):'];
fprintf(fileID,'%s\n', header);
str1 = ['by Thymidine Incorporation (95% CI): %' num2str(IncoAllStats(2)) ' (' num2str(IncoAllStats(1)) ',' num2str(IncoAllStats(3)) ')'];
fprintf(fileID,'%s\n', str1);
str2 = ['by IL-2 ELISpot (95% CI): %' num2str(ELISAllStats(2)) ' (' num2str(ELISAllStats(1)) ',' num2str(ELISAllStats(3)) ')'];
fprintf(fileID,'%s\n', str2);
str3 = ['by Combined Thymidine Incorporation & IL-2 ELISpot (95% CI): %' num2str(COMBOAllStats(2)) ' (' num2str(COMBOAllStats(1)) ',' num2str(COMBOAllStats(3)) ')'];
fprintf(fileID,'%s\n', str3);
str4 = '--';
fprintf(fileID,'%s\n', str4);
str5 = ['%Similarity between Thymidine Incorporation & IL-2 ELISpot predictions (95% CI): %' num2str(SimilarityStats(2)) ' (' num2str(SimilarityStats(1)) ',' num2str(SimilarityStats(3)) ')'];
fprintf(fileID,'%s\n', str5);
fclose(fileID);

%Write Raw data
dlmwrite([antigenname '_' cohortname '_IncorporationRaw.dat'],IncoBinary,'delimiter',',');
dlmwrite([antigenname '_' cohortname '_ELISpotRaw.dat'],ELISBinary,'delimiter',',');
dlmwrite([antigenname '_' cohortname '_COMBORaw.dat'],COMBOBinary,'delimiter',',');
cd ../Bin

%Clean up parameters file
delete Parameters.mat