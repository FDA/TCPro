function NumCellsper_ml = distributionofCells(MinNumPBMCs,MaxNumPBMCs,seed)
%DISTRIBUTIONOFCELLS() Calculates and presents the initial frequency of
%cells in assay wells randomly selected from within total cell frequencies
%observed in PBMCs. FMINCON optimization routine is used to make sure the
%total frequencies add up to 1 (or 100%)
%   INPUTS:
%   1. MinNumPBMCs: Minimum PBMC concentration (number of cells/mililiter)
%   2. MaxNumPBMCs: Minimum PBMC concentration (number of cells/mililiter)
%   3. seed: random seed to select different cell frequencies for each run
%   OUTPUT:
%   1. NumCellsper_ml: Array containing individual cell frequencies
%   For details and citation: Yogurtcu, Osman N., et al. "TCPro: an In 
%   Silico Risk Assessment Tool for Biotherapeutic Protein Immunogenicity."
%   The AAPS journal 21.5 (2019): 96.

% Optimization function to use to make sure that cell frequencies add up to 1
fun = @(x)(sum(x)-100)^2; %x is the vector of cell percentages

%Donor cell distribution variability fixed to seed
rng(seed);

% Cell percentages: Dendritic Cells ; NK Cells; B Cells; CD4+; CD8+; Monocytes
% LowerBounds and UpperBounds
% see TCPro article for how these numbers were obtained
lb = [0.63;6.84;6.36;26.15;12.38;6.04];
ub = [1.46;35.17;16.51;48.26;33.11;11.56];

%Random initial Start Point fixed for cohort member
x0 = rand(6,1).*(ub-lb) + lb; 

%Optimization functions
options = optimoptions('fmincon','Display','off');

% Variation in the cell type distribution
x = fmincon(fun,x0,[],[],[],[],lb,ub,[],options);
% Validate x array, make sure it is 100% total
while sum(x)<99.9 || sum(x)>100.1    
    x = fmincon(fun,x,[],[],[],[],lb,ub,[],options);
end

% In the assays that TCPro mimics, CD8+ cells were depleted
% 5th row of the array is CD8+ so it will be depleted
totcellafterdepletion = sum(x([1:4 6]));
scale = 100.0/totcellafterdepletion;
x = x*scale;
x(5) = 0; % CD8 count goes to zero.

% Variation in the assay. There is a variantion in experimental measurement
% on the PBMC counts (min--max)
rng('shuffle');
rng('shuffle');
InitPBMC = rand*(MaxNumPBMCs-MinNumPBMCs) + MinNumPBMCs; %Random initial number of cells/mililiter

% Convert percentages to frequencies
NumCellsper_ml = InitPBMC*x/100;